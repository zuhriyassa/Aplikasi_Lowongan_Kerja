package com.zuhri.lowongankerja.data.repository

import com.zuhri.lowongankerja.data.api.AuthApi
import com.zuhri.lowongankerja.data.model.LoginRequest
import com.zuhri.lowongankerja.data.model.RegisterRequest
import com.zuhri.lowongankerja.util.AppConfig
import com.zuhri.lowongankerja.util.Resource
import com.zuhri.lowongankerja.util.safeApiCall

interface AuthRepository {
    /** Mengembalikan token jika berhasil. */
    suspend fun login(email: String, password: String): Resource<String>

    suspend fun register(email: String, password: String): Resource<Unit>
}

class AuthRepositoryImpl(private val api: AuthApi) : AuthRepository {

    override suspend fun login(email: String, password: String): Resource<String> {
        return when (val result = safeApiCall { api.login(LoginRequest(email, password)) }) {
            is Resource.Success -> {
                val token = result.data.token
                if (token.isNullOrBlank()) {
                    Resource.Error(result.data.error ?: "Login gagal")
                } else {
                    Resource.Success(token)
                }
            }
            is Resource.Error -> Resource.Error(friendly(result.message))
        }
    }

    override suspend fun register(email: String, password: String): Resource<Unit> {
        return when (val result = safeApiCall { api.register(RegisterRequest(email, password)) }) {
            is Resource.Success -> {
                if (result.data.token != null || result.data.id != null) {
                    Resource.Success(Unit)
                } else {
                    Resource.Error(result.data.error ?: "Registrasi gagal")
                }
            }
            is Resource.Error -> Resource.Error(friendly(result.message))
        }
    }

    // Pesan bawaan reqres kurang jelas untuk pengguna aplikasi.
    private fun friendly(message: String): String {
        return when {
            message.contains("rate_limit", ignoreCase = true) ||
                message.contains("HTTP 429") ->
                "Batas pemakaian server demo tercapai. Coba lagi nanti atau isi REQRES_API_KEY."
            message.contains("Only defined users", ignoreCase = true) ||
                message.contains("user not found", ignoreCase = true) ->
                "Mode demo: gunakan akun uji ${AppConfig.DEMO_EMAIL}"
            else -> message
        }
    }
}
