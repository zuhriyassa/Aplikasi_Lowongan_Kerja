package com.zuhri.lowongankerja.ui.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.zuhri.lowongankerja.R
import com.zuhri.lowongankerja.databinding.ItemJobBinding

class JobAdapter(
    private val onItemClick: (JobItem) -> Unit,
    private val onBookmarkClick: (JobItem) -> Unit
) : ListAdapter<JobItem, JobAdapter.JobViewHolder>(JobDiffCallback()) {

    inner class JobViewHolder(private val binding: ItemJobBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: JobItem) {
            val job = item.job
            binding.tvTitle.text = job.title
            binding.tvCompany.text = job.company
            binding.tvLocation.text = job.location
            binding.tvMeta.text = "${job.type.label} • ${postedText(job.postedDaysAgo)}"
            binding.tvSalary.text = job.salary ?: "Gaji tidak disebutkan"

            binding.btnBookmark.setImageResource(
                if (item.isBookmarked) R.drawable.ic_bookmark else R.drawable.ic_bookmark_border
            )
            binding.btnBookmark.contentDescription =
                if (item.isBookmarked) "Hapus dari tersimpan" else "Simpan lowongan"

            binding.root.setOnClickListener { onItemClick(item) }
            binding.btnBookmark.setOnClickListener { onBookmarkClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        val binding = ItemJobBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return JobViewHolder(binding)
    }

    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}

fun postedText(daysAgo: Int): String = when {
    daysAgo <= 0 -> "Hari ini"
    daysAgo == 1 -> "Kemarin"
    else -> "$daysAgo hari lalu"
}

class JobDiffCallback : DiffUtil.ItemCallback<JobItem>() {
    override fun areItemsTheSame(oldItem: JobItem, newItem: JobItem) =
        oldItem.job.id == newItem.job.id

    override fun areContentsTheSame(oldItem: JobItem, newItem: JobItem) =
        oldItem == newItem
}
