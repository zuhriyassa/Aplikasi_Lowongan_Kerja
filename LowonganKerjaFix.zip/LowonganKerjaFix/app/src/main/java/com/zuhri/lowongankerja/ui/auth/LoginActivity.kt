package com.zuhri.lowongankerja.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.zuhri.lowongankerja.databinding.ActivityLoginBinding
import com.zuhri.lowongankerja.ui.dashboard.DashboardActivity
import com.zuhri.lowongankerja.util.AppConfig
import com.zuhri.lowongankerja.util.Validator
import com.zuhri.lowongankerja.util.appViewModel
import com.zuhri.lowongankerja.util.observeEvent
import com.zuhri.lowongankerja.util.setVisible
import com.zuhri.lowongankerja.util.toast

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val viewModel: AuthViewModel by appViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvDemoHint.text = if (AppConfig.USE_FAKE_AUTH) {
            "Mode demo: email apa pun + password minimal 6 karakter"
        } else {
            "Mode demo: ${AppConfig.DEMO_EMAIL} / ${AppConfig.DEMO_LOGIN_PASSWORD}"
        }

        binding.btnLogin.setOnClickListener { attemptLogin() }
        binding.tvGoToRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        observeViewModel()
    }

    private fun attemptLogin() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString()

        val emailError = Validator.emailError(email)
        val passwordError = Validator.passwordError(password)
        binding.tilEmail.error = emailError
        binding.tilPassword.error = passwordError
        if (emailError != null || passwordError != null) return

        viewModel.login(email, password)
    }

    private fun observeViewModel() {
        viewModel.loading.observe(this) { loading ->
            binding.progressBar.setVisible(loading)
            binding.btnLogin.isEnabled = !loading
        }
        viewModel.message.observeEvent(this) { toast(it) }
        viewModel.loginSuccess.observeEvent(this) {
            toast("Login berhasil")
            startActivity(
                Intent(this, DashboardActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
            finish()
        }
    }
}
