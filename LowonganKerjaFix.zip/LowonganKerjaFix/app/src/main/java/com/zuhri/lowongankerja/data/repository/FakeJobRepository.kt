package com.zuhri.lowongankerja.data.repository

import com.zuhri.lowongankerja.data.model.Job
import com.zuhri.lowongankerja.data.model.JobType
import com.zuhri.lowongankerja.util.Resource
import kotlinx.coroutines.delay

/** Data contoh lokal supaya aplikasi bisa dijalankan tanpa backend. */
class FakeJobRepository : JobRepository {

    override suspend fun getJobs(): Resource<List<Job>> {
        delay(600) // meniru waktu tunggu jaringan
        return Resource.Success(sampleJobs)
    }

    override suspend fun getJob(id: Int): Resource<Job> {
        delay(300)
        val job = sampleJobs.firstOrNull { it.id == id }
        return if (job != null) Resource.Success(job) else Resource.Error("Lowongan tidak ditemukan")
    }

    private val sampleJobs = listOf(
        Job(
            id = 1,
            title = "Android Developer",
            company = "PT Nusantara Digital",
            location = "Medan, Sumatera Utara",
            salary = "Rp 7.000.000 - Rp 10.000.000",
            type = JobType.FULL_TIME,
            description = "Mengembangkan dan memelihara aplikasi Android untuk klien perusahaan. " +
                "Bekerja dalam tim kecil dengan siklus rilis dua mingguan.",
            requirements = listOf(
                "Menguasai Kotlin dan arsitektur MVVM",
                "Pengalaman dengan Retrofit dan Coroutines",
                "Memahami Git",
                "Minimal D3/S1 Informatika atau Sistem Informasi"
            ),
            contactEmail = "hrd@example.com",
            postedDaysAgo = 1
        ),
        Job(
            id = 2,
            title = "Staf Administrasi",
            company = "CV Maju Bersama",
            location = "Pematangsiantar, Sumatera Utara",
            salary = "Rp 3.200.000",
            type = JobType.FULL_TIME,
            description = "Mengelola dokumen, surat-menyurat, dan pencatatan data harian kantor.",
            requirements = listOf(
                "Menguasai Microsoft Office",
                "Teliti dan rapi",
                "Pendidikan minimal SMK/D3"
            ),
            contactEmail = "hrd@example.com",
            postedDaysAgo = 2
        ),
        Job(
            id = 3,
            title = "Magang Web Developer",
            company = "Kreasi Teknologi",
            location = "Medan, Sumatera Utara",
            salary = "Rp 1.500.000 (uang saku)",
            type = JobType.INTERNSHIP,
            description = "Membantu tim membangun halaman web dan memperbaiki bug. " +
                "Cocok untuk mahasiswa semester akhir yang ingin pengalaman kerja.",
            requirements = listOf(
                "Dasar HTML, CSS, JavaScript",
                "Mahasiswa aktif Informatika/Sistem Informasi",
                "Bersedia magang minimal 3 bulan"
            ),
            contactEmail = "magang@example.com",
            postedDaysAgo = 3
        ),
        Job(
            id = 4,
            title = "Data Analyst",
            company = "Sumut Analitika",
            location = "Medan, Sumatera Utara",
            salary = "Rp 6.000.000 - Rp 8.500.000",
            type = JobType.FULL_TIME,
            description = "Mengolah data penjualan, membuat dashboard, dan menyusun laporan analisis bulanan.",
            requirements = listOf(
                "Menguasai SQL dan Excel",
                "Familiar dengan Python (pandas)",
                "Mampu menyajikan hasil analisis dengan jelas"
            ),
            contactEmail = "karier@example.com",
            postedDaysAgo = 4
        ),
        Job(
            id = 5,
            title = "Admin Media Sosial",
            company = "Toko Berkah Online",
            location = "Pematangsiantar, Sumatera Utara",
            salary = "Rp 2.000.000",
            type = JobType.PART_TIME,
            description = "Mengelola akun Instagram dan TikTok toko, membalas pesan pelanggan, membuat konten sederhana.",
            requirements = listOf(
                "Bisa membuat desain sederhana (Canva)",
                "Aktif di media sosial",
                "Jam kerja fleksibel 4 jam per hari"
            ),
            contactEmail = "hrd@example.com",
            postedDaysAgo = 5
        ),
        Job(
            id = 6,
            title = "UI/UX Designer",
            company = "PT Kreasi Antarmuka",
            location = "Jakarta (Remote)",
            salary = "Rp 8.000.000 - Rp 12.000.000",
            type = JobType.CONTRACT,
            description = "Merancang antarmuka aplikasi mobile dan web, membuat prototipe, serta riset pengguna.",
            requirements = listOf(
                "Menguasai Figma",
                "Portofolio desain aplikasi",
                "Kontrak 12 bulan, bisa diperpanjang"
            ),
            contactEmail = "design@example.com",
            postedDaysAgo = 6
        ),
        Job(
            id = 7,
            title = "Teknisi Jaringan",
            company = "Mitra Net Sumatera",
            location = "Pematangsiantar, Sumatera Utara",
            salary = "Rp 4.000.000 - Rp 5.500.000",
            type = JobType.FULL_TIME,
            description = "Instalasi dan perawatan jaringan internet pelanggan serta pemantauan perangkat.",
            requirements = listOf(
                "Memahami dasar jaringan komputer (TCP/IP)",
                "Bersedia kerja lapangan",
                "Memiliki SIM C"
            ),
            contactEmail = "teknisi@example.com",
            postedDaysAgo = 7
        ),
        Job(
            id = 8,
            title = "Customer Service",
            company = "Bank Mitra Rakyat",
            location = "Medan, Sumatera Utara",
            salary = "Rp 3.800.000",
            type = JobType.CONTRACT,
            description = "Melayani nasabah, menangani keluhan, dan membantu pembukaan rekening.",
            requirements = listOf(
                "Komunikatif dan ramah",
                "Pendidikan minimal D3 semua jurusan",
                "Berpenampilan rapi"
            ),
            contactEmail = "cs@example.com",
            postedDaysAgo = 8
        ),
        Job(
            id = 9,
            title = "Magang Data Entry",
            company = "Dinas Digital Daerah",
            location = "Pematangsiantar, Sumatera Utara",
            salary = null,
            type = JobType.INTERNSHIP,
            description = "Membantu input dan verifikasi data administrasi kependudukan ke sistem informasi.",
            requirements = listOf(
                "Mahasiswa aktif",
                "Teliti dan jujur",
                "Bersedia ditempatkan di kantor dinas"
            ),
            contactEmail = "magang@example.com",
            postedDaysAgo = 9
        ),
        Job(
            id = 10,
            title = "Backend Developer (Laravel)",
            company = "Solusi Perangkat Lunak Medan",
            location = "Medan, Sumatera Utara",
            salary = "Rp 8.000.000 - Rp 11.000.000",
            type = JobType.FULL_TIME,
            description = "Membangun REST API dan sistem informasi berbasis web untuk klien instansi dan swasta.",
            requirements = listOf(
                "Pengalaman Laravel dan MySQL",
                "Paham REST API dan autentikasi token",
                "Terbiasa bekerja dengan Git"
            ),
            contactEmail = "hrd@example.com",
            postedDaysAgo = 10
        )
    )
}
