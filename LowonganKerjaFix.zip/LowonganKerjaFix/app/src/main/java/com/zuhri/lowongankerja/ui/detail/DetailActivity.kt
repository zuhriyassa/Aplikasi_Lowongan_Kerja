package com.zuhri.lowongankerja.ui.detail

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.zuhri.lowongankerja.data.model.Job
import com.zuhri.lowongankerja.databinding.ActivityDetailBinding
import com.zuhri.lowongankerja.ui.dashboard.postedText
import com.zuhri.lowongankerja.util.appViewModel
import com.zuhri.lowongankerja.util.setVisible
import com.zuhri.lowongankerja.util.toast

class DetailActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_JOB_ID = "extra_job_id"

        fun start(context: Context, jobId: Int) {
            context.startActivity(
                Intent(context, DetailActivity::class.java).putExtra(EXTRA_JOB_ID, jobId)
            )
        }
    }

    private lateinit var binding: ActivityDetailBinding
    private val viewModel: DetailViewModel by appViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        title = "Detail Lowongan"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val jobId = intent.getIntExtra(EXTRA_JOB_ID, -1)
        if (jobId == -1) {
            finish()
            return
        }

        binding.btnBookmark.setOnClickListener { viewModel.toggleBookmark() }

        observeViewModel()
        viewModel.load(jobId)
    }

    private fun observeViewModel() {
        viewModel.loading.observe(this) { binding.progressBar.setVisible(it) }

        viewModel.error.observe(this) { message ->
            binding.tvError.setVisible(message != null)
            binding.tvError.text = message.orEmpty()
        }

        viewModel.job.observe(this) { job ->
            binding.scrollContent.setVisible(job != null)
            if (job != null) showJob(job)
        }

        viewModel.bookmarked.observe(this) { saved ->
            binding.btnBookmark.text = if (saved) "Hapus dari tersimpan" else "Simpan lowongan"
        }
    }

    private fun showJob(job: Job) {
        binding.tvTitle.text = job.title
        binding.tvCompany.text = job.company
        binding.tvLocation.text = job.location
        binding.tvMeta.text = "${job.type.label} • ${postedText(job.postedDaysAgo)}"
        binding.tvSalary.text = job.salary ?: "Gaji tidak disebutkan"
        binding.tvDescription.text =
            if (job.description.isBlank()) "Belum ada deskripsi." else job.description
        binding.tvRequirements.text =
            if (job.requirements.isEmpty()) {
                "Belum ada persyaratan."
            } else {
                job.requirements.joinToString("\n") { "• $it" }
            }

        binding.btnApply.setOnClickListener { applyByEmail(job) }
    }

    private fun applyByEmail(job: Job) {
        if (job.contactEmail.isBlank()) {
            toast("Kontak lamaran belum tersedia")
            return
        }
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
            putExtra(Intent.EXTRA_EMAIL, arrayOf(job.contactEmail))
            putExtra(Intent.EXTRA_SUBJECT, "Lamaran: ${job.title}")
            putExtra(
                Intent.EXTRA_TEXT,
                "Yth. HRD ${job.company},\n\nSaya ingin melamar posisi ${job.title}.\n\nTerima kasih."
            )
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast("Tidak ada aplikasi email di perangkat ini")
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
