package com.zuhri.lowongankerja

import android.app.Application
import com.zuhri.lowongankerja.di.AppContainer

class LowonganApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
