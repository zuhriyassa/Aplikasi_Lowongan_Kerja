package com.zuhri.lowongankerja.ui.auth

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.zuhri.lowongankerja.databinding.ActivityRegisterBinding
import com.zuhri.lowongankerja.util.AppConfig
import com.zuhri.lowongankerja.util.Validator
import com.zuhri.lowongankerja.util.appViewModel
import com.zuhri.lowongankerja.util.observeEvent
import com.zuhri.lowongankerja.util.setVisible
import com.zuhri.lowongankerja.util.toast

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private val viewModel: AuthViewModel by appViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvDemoHint.text = if (AppConfig.USE_FAKE_AUTH) {
            "Mode demo: email apa pun yang valid dapat didaftarkan"
        } else {
            "Mode demo: hanya email ${AppConfig.DEMO_EMAIL} yang dapat didaftarkan"
        }

        binding.btnRegister.setOnClickListener { attemptRegister() }

        viewModel.loading.observe(this) { loading ->
            binding.progressBar.setVisible(loading)
            binding.btnRegister.isEnabled = !loading
        }
        viewModel.message.observeEvent(this) { toast(it) }
        viewModel.registerSuccess.observeEvent(this) {
            toast("Registrasi berhasil, silakan login")
            finish()
        }
    }

    private fun attemptRegister() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString()

        val emailError = Validator.emailError(email)
        val passwordError = Validator.passwordError(password)
        binding.tilEmail.error = emailError
        binding.tilPassword.error = passwordError
        if (emailError != null || passwordError != null) return

        viewModel.register(email, password)
    }
}
