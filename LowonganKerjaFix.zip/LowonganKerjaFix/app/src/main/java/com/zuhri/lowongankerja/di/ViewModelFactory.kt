package com.zuhri.lowongankerja.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.zuhri.lowongankerja.ui.auth.AuthViewModel
import com.zuhri.lowongankerja.ui.dashboard.DashboardViewModel
import com.zuhri.lowongankerja.ui.detail.DetailViewModel

class ViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(AuthViewModel::class.java) ->
                AuthViewModel(container.authRepository, container.sessionManager) as T

            modelClass.isAssignableFrom(DashboardViewModel::class.java) ->
                DashboardViewModel(
                    container.jobRepository,
                    container.bookmarkStore,
                    container.sessionManager
                ) as T

            modelClass.isAssignableFrom(DetailViewModel::class.java) ->
                DetailViewModel(container.jobRepository, container.bookmarkStore) as T

            else -> throw IllegalArgumentException("ViewModel tidak dikenal: ${modelClass.name}")
        }
    }
}
