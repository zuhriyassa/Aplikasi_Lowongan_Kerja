package com.zuhri.lowongankerja.util

import kotlinx.coroutines.CancellationException
import org.json.JSONObject
import retrofit2.HttpException
import java.io.IOException

/** Pembungkus hasil operasi: sukses membawa data, gagal membawa pesan untuk pengguna. */
sealed class Resource<out T> {
    data class Success<out T>(val data: T) : Resource<T>()
    data class Error(val message: String) : Resource<Nothing>()
}

/** Jalankan panggilan API dan ubah semua kegagalan menjadi Resource.Error dengan pesan yang jelas. */
suspend fun <T> safeApiCall(block: suspend () -> T): Resource<T> {
    return try {
        Resource.Success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: HttpException) {
        Resource.Error(e.toUserMessage())
    } catch (e: IOException) {
        Resource.Error("Tidak dapat terhubung ke server. Periksa koneksi internet.")
    } catch (e: Exception) {
        Resource.Error(e.message ?: "Terjadi kesalahan tak terduga")
    }
}

private fun HttpException.toUserMessage(): String {
    val body = try {
        response()?.errorBody()?.string()
    } catch (e: Exception) {
        null
    }
    val serverMessage = try {
        if (!body.isNullOrBlank()) JSONObject(body).optString("error") else ""
    } catch (e: Exception) {
        ""
    }
    return if (serverMessage.isNotBlank()) serverMessage else "Permintaan gagal (HTTP ${code()})"
}
