package com.zuhri.lowongankerja

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.zuhri.lowongankerja.ui.auth.LoginActivity
import com.zuhri.lowongankerja.ui.dashboard.DashboardActivity
import com.zuhri.lowongankerja.util.container
import kotlinx.coroutines.launch

/** Hanya penentu arah: sudah login -> Dashboard, belum -> Login. */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lifecycleScope.launch {
            val token = container.sessionManager.getToken()
            val target = if (token.isNullOrBlank()) {
                LoginActivity::class.java
            } else {
                DashboardActivity::class.java
            }
            startActivity(Intent(this@MainActivity, target))
            finish()
        }
    }
}
