package com.zuhri.lowongankerja.data.repository

import com.zuhri.lowongankerja.data.model.Job
import com.zuhri.lowongankerja.util.Resource

/**
 * Sumber data lowongan. UI hanya tahu interface ini, jadi sumber data bisa diganti
 * (lokal, REST API, Firebase, Room) tanpa mengubah ViewModel atau Activity.
 */
interface JobRepository {
    suspend fun getJobs(): Resource<List<Job>>
    suspend fun getJob(id: Int): Resource<Job>
}
