package com.zuhri.lowongankerja.data.api

import com.zuhri.lowongankerja.data.model.*
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface AuthApi {
    @POST("api/login")
    suspend fun login(@Body request: LoginRequest): LoginResponse

    @POST("api/register")
    suspend fun register(@Body request: RegisterRequest): RegisterResponse
}

/** Kontrak API lowongan untuk backend Anda nanti. Sesuaikan path dengan server. */
interface JobApi {
    @GET("jobs")
    suspend fun getJobs(): List<Job>

    @GET("jobs/{id}")
    suspend fun getJob(@Path("id") id: Int): Job
}
