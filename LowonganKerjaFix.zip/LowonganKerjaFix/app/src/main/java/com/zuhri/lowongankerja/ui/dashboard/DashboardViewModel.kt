package com.zuhri.lowongankerja.ui.dashboard

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zuhri.lowongankerja.data.local.BookmarkStore
import com.zuhri.lowongankerja.data.local.SessionManager
import com.zuhri.lowongankerja.data.model.Job
import com.zuhri.lowongankerja.data.model.JobType
import com.zuhri.lowongankerja.data.repository.JobRepository
import com.zuhri.lowongankerja.util.Event
import com.zuhri.lowongankerja.util.Resource
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

class DashboardViewModel(
    private val jobRepository: JobRepository,
    private val bookmarkStore: BookmarkStore,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val _jobs = MutableLiveData<List<JobItem>>(emptyList())
    val jobs: LiveData<List<JobItem>> = _jobs

    private val _loading = MutableLiveData(false)
    val loading: LiveData<Boolean> = _loading

    private val _error = MutableLiveData<Event<String>>()
    val error: LiveData<Event<String>> = _error

    private val _loggedOut = MutableLiveData<Event<Unit>>()
    val loggedOut: LiveData<Event<Unit>> = _loggedOut

    // Data mentah + kriteria filter. Filter dijalankan di sini (sisi klien);
    // kalau data sudah besar, pindahkan ke parameter query API.
    private var allJobs: List<Job> = emptyList()
    private var bookmarkIds: Set<Int> = emptySet()
    private var query: String = ""
    private var type: JobType? = null
    private var onlyBookmarked: Boolean = false

    init {
        bookmarkStore.ids
            .onEach { ids ->
                bookmarkIds = ids
                publish()
            }
            .launchIn(viewModelScope)
        loadJobs()
    }

    fun loadJobs() {
        if (_loading.value == true) return
        viewModelScope.launch {
            _loading.value = true
            when (val result = jobRepository.getJobs()) {
                is Resource.Success -> {
                    allJobs = result.data
                    publish()
                }
                is Resource.Error -> _error.value = Event(result.message)
            }
            _loading.value = false
        }
    }

    fun setQuery(value: String) {
        query = value
        publish()
    }

    fun setType(value: JobType?) {
        type = value
        publish()
    }

    fun setOnlyBookmarked(value: Boolean) {
        onlyBookmarked = value
        publish()
    }

    fun toggleBookmark(jobId: Int) {
        viewModelScope.launch { bookmarkStore.toggle(jobId) }
    }

    fun logout() {
        viewModelScope.launch {
            sessionManager.clear()
            _loggedOut.value = Event(Unit)
        }
    }

    private fun publish() {
        val q = query.trim().lowercase()
        _jobs.value = allJobs.asSequence()
            .filter { type == null || it.type == type }
            .filter { !onlyBookmarked || it.id in bookmarkIds }
            .filter {
                q.isEmpty() ||
                    it.title.lowercase().contains(q) ||
                    it.company.lowercase().contains(q) ||
                    it.location.lowercase().contains(q)
            }
            .map { JobItem(it, it.id in bookmarkIds) }
            .toList()
    }
}
