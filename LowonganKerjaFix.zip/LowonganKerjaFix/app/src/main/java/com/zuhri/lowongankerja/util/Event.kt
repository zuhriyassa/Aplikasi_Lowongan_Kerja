package com.zuhri.lowongankerja.util

/** Untuk kejadian sekali pakai (toast, navigasi) agar tidak terulang saat layar diputar. */
open class Event<out T>(private val content: T) {
    private var handled = false

    fun getContentIfNotHandled(): T? {
        return if (handled) {
            null
        } else {
            handled = true
            content
        }
    }
}
