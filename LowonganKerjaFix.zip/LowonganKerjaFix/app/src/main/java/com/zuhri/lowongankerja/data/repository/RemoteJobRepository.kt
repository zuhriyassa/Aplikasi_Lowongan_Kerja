package com.zuhri.lowongankerja.data.repository

import com.zuhri.lowongankerja.data.api.JobApi
import com.zuhri.lowongankerja.data.model.Job
import com.zuhri.lowongankerja.util.Resource
import com.zuhri.lowongankerja.util.safeApiCall

/** Aktifkan dengan AppConfig.USE_REMOTE_JOBS = true setelah backend siap. */
class RemoteJobRepository(private val api: JobApi) : JobRepository {
    override suspend fun getJobs(): Resource<List<Job>> = safeApiCall { api.getJobs() }
    override suspend fun getJob(id: Int): Resource<Job> = safeApiCall { api.getJob(id) }
}
