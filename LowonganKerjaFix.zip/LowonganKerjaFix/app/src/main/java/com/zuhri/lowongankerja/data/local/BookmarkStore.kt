package com.zuhri.lowongankerja.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Menyimpan id lowongan yang ditandai pengguna. Bisa diganti Room kalau datanya makin kompleks. */
class BookmarkStore(private val context: Context) {

    private val key = stringSetPreferencesKey("bookmarked_job_ids")

    val ids: Flow<Set<Int>> = context.appDataStore.data
        .emptyOnIoError()
        .map { prefs -> prefs[key].orEmpty().mapNotNull { it.toIntOrNull() }.toSet() }

    suspend fun toggle(jobId: Int) {
        context.appDataStore.edit { prefs ->
            val current = prefs[key].orEmpty().toMutableSet()
            val id = jobId.toString()
            if (!current.remove(id)) current.add(id)
            prefs[key] = current
        }
    }
}
