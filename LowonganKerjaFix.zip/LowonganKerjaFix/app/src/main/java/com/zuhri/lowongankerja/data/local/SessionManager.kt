package com.zuhri.lowongankerja.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class SessionManager(private val context: Context) {

    private companion object {
        val TOKEN_KEY = stringPreferencesKey("auth_token")
        val EMAIL_KEY = stringPreferencesKey("auth_email")
    }

    val tokenFlow: Flow<String?> =
        context.appDataStore.data.emptyOnIoError().map { it[TOKEN_KEY] }

    suspend fun saveSession(token: String, email: String) {
        context.appDataStore.edit { prefs ->
            prefs[TOKEN_KEY] = token
            prefs[EMAIL_KEY] = email
        }
    }

    suspend fun getToken(): String? = tokenFlow.first()

    suspend fun getEmail(): String? =
        context.appDataStore.data.emptyOnIoError().map { it[EMAIL_KEY] }.first()

    suspend fun clear() {
        context.appDataStore.edit { prefs ->
            prefs.remove(TOKEN_KEY)
            prefs.remove(EMAIL_KEY)
        }
    }
}
