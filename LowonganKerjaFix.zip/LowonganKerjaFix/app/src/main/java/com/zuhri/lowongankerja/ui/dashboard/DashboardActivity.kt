package com.zuhri.lowongankerja.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.zuhri.lowongankerja.R
import com.zuhri.lowongankerja.data.model.JobType
import com.zuhri.lowongankerja.databinding.ActivityDashboardBinding
import com.zuhri.lowongankerja.ui.auth.LoginActivity
import com.zuhri.lowongankerja.ui.detail.DetailActivity
import com.zuhri.lowongankerja.util.appViewModel
import com.zuhri.lowongankerja.util.observeEvent
import com.zuhri.lowongankerja.util.setVisible
import com.zuhri.lowongankerja.util.toast

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding
    private val viewModel: DashboardViewModel by appViewModel()
    private lateinit var adapter: JobAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        title = "Lowongan Kerja"

        adapter = JobAdapter(
            onItemClick = { DetailActivity.start(this, it.job.id) },
            onBookmarkClick = { viewModel.toggleBookmark(it.job.id) }
        )
        binding.recyclerJobs.layoutManager = LinearLayoutManager(this)
        binding.recyclerJobs.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { viewModel.loadJobs() }

        binding.chipGroupType.setOnCheckedStateChangeListener { _, checkedIds ->
            val type = when (checkedIds.firstOrNull()) {
                R.id.chipFullTime -> JobType.FULL_TIME
                R.id.chipPartTime -> JobType.PART_TIME
                R.id.chipInternship -> JobType.INTERNSHIP
                R.id.chipContract -> JobType.CONTRACT
                else -> null
            }
            viewModel.setType(type)
        }

        observeViewModel()
    }

    private fun observeViewModel() {
        viewModel.jobs.observe(this) { items ->
            adapter.submitList(items)
            binding.tvCount.text = "${items.size} lowongan"
            updateEmptyState()
        }
        viewModel.loading.observe(this) { loading ->
            binding.swipeRefresh.isRefreshing = loading
            updateEmptyState()
        }
        viewModel.error.observeEvent(this) { toast(it) }
        viewModel.loggedOut.observeEvent(this) {
            startActivity(
                Intent(this, LoginActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
            finish()
        }
    }

    private fun updateEmptyState() {
        val isEmpty = viewModel.jobs.value.isNullOrEmpty()
        val isLoading = viewModel.loading.value == true
        binding.tvEmpty.setVisible(isEmpty && !isLoading)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_dashboard, menu)

        val searchView = menu.findItem(R.id.action_search).actionView as SearchView
        searchView.queryHint = "Cari posisi, perusahaan, kota"
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = true

            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.setQuery(newText.orEmpty())
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_bookmarks -> {
                item.isChecked = !item.isChecked
                viewModel.setOnlyBookmarked(item.isChecked)
                true
            }
            R.id.action_logout -> {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Keluar")
                    .setMessage("Anda yakin ingin keluar dari akun?")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Keluar") { _, _ -> viewModel.logout() }
                    .show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
