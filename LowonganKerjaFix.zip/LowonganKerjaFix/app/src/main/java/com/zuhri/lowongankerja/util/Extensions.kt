package com.zuhri.lowongankerja.util

import android.content.Context
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.zuhri.lowongankerja.LowonganApp
import com.zuhri.lowongankerja.di.AppContainer
import com.zuhri.lowongankerja.di.ViewModelFactory

val Context.container: AppContainer
    get() = (applicationContext as LowonganApp).container

/** Ambil ViewModel lewat factory aplikasi: `private val viewModel: XViewModel by appViewModel()` */
inline fun <reified VM : ViewModel> AppCompatActivity.appViewModel(): Lazy<VM> =
    lazy { ViewModelProvider(this, ViewModelFactory(container))[VM::class.java] }

fun Context.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

fun View.setVisible(visible: Boolean) {
    visibility = if (visible) View.VISIBLE else View.GONE
}

fun <T> LiveData<Event<T>>.observeEvent(owner: LifecycleOwner, onEvent: (T) -> Unit) {
    observe(owner, Observer { event ->
        event.getContentIfNotHandled()?.let(onEvent)
    })
}
