package com.zuhri.lowongankerja.data.local

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import java.io.IOException

/** Satu DataStore untuk seluruh aplikasi. Jangan dideklarasikan lebih dari sekali dengan nama sama. */
internal val Context.appDataStore by preferencesDataStore(name = "app_prefs")

internal fun Flow<Preferences>.emptyOnIoError(): Flow<Preferences> =
    catch { e ->
        if (e is IOException) emit(emptyPreferences()) else throw e
    }
