package com.zuhri.lowongankerja.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zuhri.lowongankerja.data.local.BookmarkStore
import com.zuhri.lowongankerja.data.model.Job
import com.zuhri.lowongankerja.data.repository.JobRepository
import com.zuhri.lowongankerja.util.Resource
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

class DetailViewModel(
    private val jobRepository: JobRepository,
    private val bookmarkStore: BookmarkStore
) : ViewModel() {

    private val _job = MutableLiveData<Job?>()
    val job: LiveData<Job?> = _job

    private val _loading = MutableLiveData(false)
    val loading: LiveData<Boolean> = _loading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    private val _bookmarked = MutableLiveData(false)
    val bookmarked: LiveData<Boolean> = _bookmarked

    private var jobId: Int = -1
    private var bookmarkIds: Set<Int> = emptySet()

    init {
        bookmarkStore.ids
            .onEach { ids ->
                bookmarkIds = ids
                _bookmarked.value = jobId in ids
            }
            .launchIn(viewModelScope)
    }

    fun load(id: Int) {
        if (jobId == id && _job.value != null) return
        jobId = id
        _bookmarked.value = id in bookmarkIds
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            when (val result = jobRepository.getJob(id)) {
                is Resource.Success -> _job.value = result.data
                is Resource.Error -> _error.value = result.message
            }
            _loading.value = false
        }
    }

    fun toggleBookmark() {
        if (jobId < 0) return
        viewModelScope.launch { bookmarkStore.toggle(jobId) }
    }
}
