package com.zuhri.lowongankerja.ui.dashboard

import com.zuhri.lowongankerja.data.model.Job

/** Model untuk tampilan daftar: lowongan + status tersimpan. */
data class JobItem(val job: Job, val isBookmarked: Boolean)
