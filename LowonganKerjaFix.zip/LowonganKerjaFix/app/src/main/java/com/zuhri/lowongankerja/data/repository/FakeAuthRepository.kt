package com.zuhri.lowongankerja.data.repository

import com.zuhri.lowongankerja.util.Resource
import kotlinx.coroutines.delay

/**
 * Autentikasi simulasi tanpa jaringan. Email dan password sudah divalidasi di layar
 * (format email, password minimal 6 karakter), jadi semua input valid diterima.
 * Ganti ke AuthRepositoryImpl lewat AppConfig.USE_FAKE_AUTH = false.
 */
class FakeAuthRepository : AuthRepository {

    override suspend fun login(email: String, password: String): Resource<String> {
        delay(400) // meniru waktu respons jaringan agar indikator loading terlihat
        return Resource.Success("fake-token-${email.lowercase().hashCode()}")
    }

    override suspend fun register(email: String, password: String): Resource<Unit> {
        delay(400)
        return Resource.Success(Unit)
    }
}
