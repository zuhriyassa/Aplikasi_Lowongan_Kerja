package com.zuhri.lowongankerja.util

import android.util.Patterns

object Validator {
    fun emailError(email: String): String? = when {
        email.isBlank() -> "Email wajib diisi"
        !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> "Format email tidak valid"
        else -> null
    }

    fun passwordError(password: String): String? = when {
        password.isBlank() -> "Password wajib diisi"
        password.length < 6 -> "Password minimal 6 karakter"
        else -> null
    }
}
