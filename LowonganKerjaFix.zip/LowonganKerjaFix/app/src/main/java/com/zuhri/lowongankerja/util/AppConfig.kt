package com.zuhri.lowongankerja.util

/**
 * Semua pengaturan yang sering berubah ada di sini.
 */
object AppConfig {
    /** API autentikasi (simulasi). Hanya akun uji reqres yang bisa daftar/login. */
    const val AUTH_BASE_URL = "https://reqres.in/"

    /** API key gratis dari app.reqres.in (header x-api-key). Kosongkan jika tidak dipakai. */
    const val REQRES_API_KEY = ""

    /**
     * true  = login/daftar dilayani lokal (FakeAuthRepository), tanpa internet dan tanpa
     *         batas pemakaian. Cocok untuk demo dan pengembangan UI.
     * false = pakai reqres.in (butuh REQRES_API_KEY agar tidak kena rate limit).
     */
    const val USE_FAKE_AUTH = true

    /** Ganti dengan URL backend lowongan Anda sendiri. Harus diakhiri "/". */
    const val JOB_BASE_URL = "https://api.example.com/"

    /**
     * false = pakai data lowongan lokal (FakeJobRepository).
     * true  = ambil dari JOB_BASE_URL (RemoteJobRepository).
     */
    const val USE_REMOTE_JOBS = false

    const val DEMO_EMAIL = "eve.holt@reqres.in"
    const val DEMO_LOGIN_PASSWORD = "cityslicka"
}
