package com.zuhri.lowongankerja.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zuhri.lowongankerja.data.local.SessionManager
import com.zuhri.lowongankerja.data.repository.AuthRepository
import com.zuhri.lowongankerja.util.Event
import com.zuhri.lowongankerja.util.Resource
import kotlinx.coroutines.launch

class AuthViewModel(
    private val repository: AuthRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val _loading = MutableLiveData(false)
    val loading: LiveData<Boolean> = _loading

    private val _message = MutableLiveData<Event<String>>()
    val message: LiveData<Event<String>> = _message

    private val _loginSuccess = MutableLiveData<Event<Unit>>()
    val loginSuccess: LiveData<Event<Unit>> = _loginSuccess

    private val _registerSuccess = MutableLiveData<Event<Unit>>()
    val registerSuccess: LiveData<Event<Unit>> = _registerSuccess

    fun login(email: String, password: String) {
        if (_loading.value == true) return
        viewModelScope.launch {
            _loading.value = true
            when (val result = repository.login(email, password)) {
                is Resource.Success -> {
                    sessionManager.saveSession(result.data, email)
                    _loginSuccess.value = Event(Unit)
                }
                is Resource.Error -> _message.value = Event(result.message)
            }
            _loading.value = false
        }
    }

    fun register(email: String, password: String) {
        if (_loading.value == true) return
        viewModelScope.launch {
            _loading.value = true
            when (val result = repository.register(email, password)) {
                is Resource.Success -> _registerSuccess.value = Event(Unit)
                is Resource.Error -> _message.value = Event(result.message)
            }
            _loading.value = false
        }
    }
}
