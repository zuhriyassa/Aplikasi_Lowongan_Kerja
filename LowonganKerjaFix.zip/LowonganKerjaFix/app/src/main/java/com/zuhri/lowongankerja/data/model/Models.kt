package com.zuhri.lowongankerja.data.model

// ----- Autentikasi -----
data class LoginRequest(val email: String, val password: String)
data class LoginResponse(val token: String?, val error: String?)

data class RegisterRequest(val email: String, val password: String)
data class RegisterResponse(val id: Int?, val token: String?, val error: String?)

// ----- Lowongan -----
enum class JobType(val label: String) {
    FULL_TIME("Full time"),
    PART_TIME("Part time"),
    INTERNSHIP("Magang"),
    CONTRACT("Kontrak")
}

data class Job(
    val id: Int,
    val title: String,
    val company: String,
    val location: String,
    val salary: String? = null,
    val type: JobType = JobType.FULL_TIME,
    val description: String = "",
    val requirements: List<String> = emptyList(),
    val contactEmail: String = "",
    val postedDaysAgo: Int = 0
)
