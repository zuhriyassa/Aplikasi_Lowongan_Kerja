package com.zuhri.lowongankerja.di

import android.content.Context
import com.zuhri.lowongankerja.data.api.RetrofitClient
import com.zuhri.lowongankerja.data.local.BookmarkStore
import com.zuhri.lowongankerja.data.local.SessionManager
import com.zuhri.lowongankerja.data.repository.AuthRepository
import com.zuhri.lowongankerja.data.repository.AuthRepositoryImpl
import com.zuhri.lowongankerja.data.repository.FakeAuthRepository
import com.zuhri.lowongankerja.data.repository.FakeJobRepository
import com.zuhri.lowongankerja.data.repository.JobRepository
import com.zuhri.lowongankerja.data.repository.RemoteJobRepository
import com.zuhri.lowongankerja.util.AppConfig

/**
 * Tempat membuat dan menyambungkan semua objek aplikasi.
 * Mengganti sumber data cukup dilakukan di sini.
 */
class AppContainer(context: Context) {
    val sessionManager = SessionManager(context)
    val bookmarkStore = BookmarkStore(context)

    private val retrofitClient = RetrofitClient { sessionManager.getToken() }

    val authRepository: AuthRepository =
        if (AppConfig.USE_FAKE_AUTH) {
            FakeAuthRepository()
        } else {
            AuthRepositoryImpl(retrofitClient.authApi)
        }

    val jobRepository: JobRepository =
        if (AppConfig.USE_REMOTE_JOBS) {
            RemoteJobRepository(retrofitClient.jobApi)
        } else {
            FakeJobRepository()
        }
}
