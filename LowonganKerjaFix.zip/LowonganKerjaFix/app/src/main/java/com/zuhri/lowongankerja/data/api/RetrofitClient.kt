package com.zuhri.lowongankerja.data.api

import com.zuhri.lowongankerja.BuildConfig
import com.zuhri.lowongankerja.util.AppConfig
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitClient(private val tokenProvider: suspend () -> String?) {

    // BASIC (bukan BODY) supaya password dan token tidak tercetak di Logcat.
    private val logging = HttpLoggingInterceptor().apply {
        level = if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor.Level.BASIC
        } else {
            HttpLoggingInterceptor.Level.NONE
        }
    }

    private val apiKeyInterceptor = Interceptor { chain ->
        val request = if (AppConfig.REQRES_API_KEY.isBlank()) {
            chain.request()
        } else {
            chain.request().newBuilder()
                .header("x-api-key", AppConfig.REQRES_API_KEY)
                .build()
        }
        chain.proceed(request)
    }

    private val bearerInterceptor = Interceptor { chain ->
        val token = runBlocking { tokenProvider() }
        val request = if (token.isNullOrBlank()) {
            chain.request()
        } else {
            chain.request().newBuilder()
                .header("Authorization", "Bearer $token")
                .build()
        }
        chain.proceed(request)
    }

    private val authClient = OkHttpClient.Builder()
        .addInterceptor(apiKeyInterceptor)
        .addInterceptor(logging)
        .build()

    private val jobClient = OkHttpClient.Builder()
        .addInterceptor(bearerInterceptor)
        .addInterceptor(logging)
        .build()

    private fun retrofit(baseUrl: String, client: OkHttpClient): Retrofit =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    val authApi: AuthApi by lazy {
        retrofit(AppConfig.AUTH_BASE_URL, authClient).create(AuthApi::class.java)
    }

    // lazy: tidak dibuat sama sekali selama USE_REMOTE_JOBS = false
    val jobApi: JobApi by lazy {
        retrofit(AppConfig.JOB_BASE_URL, jobClient).create(JobApi::class.java)
    }
}
